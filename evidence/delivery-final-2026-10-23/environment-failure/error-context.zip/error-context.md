# Instructions

- Following Playwright test failed.
- Explain why, be concise, respect Playwright best practices.
- Provide a snippet of code with the fix, if possible.

# Test info

- Name: account.spec.ts >> Ana e Bruno: isolamento e autorização de perfil e carteiras
- Location: tests\e2e\account.spec.ts:213:1

# Error details

```
Error: page.goto: net::ERR_NO_BUFFER_SPACE at http://127.0.0.1:4173/
Call log:
  - navigating to "http://127.0.0.1:4173/", waiting until "load"

```

# Test source

```ts
  1   | import { test, expect, type Page } from '@playwright/test'
  2   | import type { Profile, Session, Wallets, Order, Quote } from '../../src/api/contracts'
  3   | import { openCheckoutReview } from './checkout-ui'
  4   | 
  5   | const profilePath = '/users/user-ana/profile'
  6   | async function api<T>(page: Page, path: string, method = 'GET', body?: unknown, token?: string) {
  7   |   return page.evaluate(async ({ path, method, body, token }) => {
  8   |     const credential = token ?? localStorage.getItem('kurio:session-token')
  9   |     const response = await fetch(`/api${path}`, { method, headers: { 'Content-Type': 'application/json', ...(credential ? { Authorization: `Bearer ${credential}` } : { 'X-Guest-Cart': localStorage.getItem('kurio:guest-cart')! }) }, body: body === undefined ? undefined : JSON.stringify(body) })
  10  |     return { status: response.status, data: await response.json() }
  11  |   }, { path, method, body, token }) as Promise<{ status: number; data: T }>
  12  | }
  13  | async function control(page: Page, path: string, body: unknown = {}) { return api(page, `/__mock/${path}`, 'POST', body) }
  14  | async function login(page: Page, path = '/perfil', user = 'ana', password = 'KurioDemo!123') {
  15  |   await page.goto(path)
  16  |   const dialog = page.getByRole('dialog')
  17  |   await expect(dialog).toBeVisible()
  18  |   await dialog.getByLabel('E-mail', { exact: true }).fill(`${user}@kurio.test`)
  19  |   await dialog.getByLabel('Senha', { exact: true }).fill(password)
  20  |   await dialog.getByRole('button', { name: 'Entrar', exact: true }).click()
  21  |   await expect(page).toHaveURL(new RegExp(`${path}$`))
  22  |   await expect(dialog).not.toBeVisible()
  23  | }
  24  | async function saveProfile(page: Page) {
  25  |   const response = page.waitForResponse((response) => response.url().endsWith(`/api${profilePath}`) && response.request().method() === 'PUT')
  26  |   await page.getByRole('button', { name: 'Salvar', exact: true }).click()
  27  |   const result = await response
  28  |   expect(result.fromServiceWorker()).toBe(true)
  29  |   return result
  30  | }
  31  | async function logout(page: Page) {
  32  |   const response = page.waitForResponse((response) => response.url().endsWith('/api/session') && response.request().method() === 'DELETE')
  33  |   await page.getByRole('complementary').getByRole('button', { name: 'Sair', exact: true }).click()
  34  |   expect((await response).status()).toBe(204)
  35  |   await expect(page.getByRole('dialog')).toBeVisible()
  36  | }
  37  | const form = (page: Page, label = 'Principal') => page.getByRole('form', { name: `Editar carteira ${label}`, exact: true })
  38  | async function saveWallet(page: Page, target = form(page)) {
  39  |   const response = page.waitForResponse((response) => /\/api\/wallets(?:\/[^/]+)?$/.test(response.url()) && ['PUT', 'POST'].includes(response.request().method()))
  40  |   await target.getByRole('button', { name: 'Salvar carteira', exact: true }).click()
  41  |   return response
  42  | }
  43  | 
  44  | test.beforeEach(async ({ page }) => {
  45  |   await page.clock.install({ time: new Date('2026-10-21T12:01:00Z') })
> 46  |   await page.goto('/')
      |              ^ Error: page.goto: net::ERR_NO_BUFFER_SPACE at http://127.0.0.1:4173/
  47  |   await expect(page.getByTestId('socket-status')).toHaveText('● Ao vivo')
  48  |   expect((await control(page, 'reset')).status).toBe(200)
  49  |   await page.reload()
  50  | })
  51  | 
  52  | test('perfil e carteiras exigem autenticação e retornam à rota solicitada', async ({ page }) => {
  53  |   for (const path of ['/perfil', '/carteiras']) {
  54  |     await page.goto(path)
  55  |     await expect(page).toHaveURL(new RegExp(`/login\\?.*redirect=.*${path.slice(1)}`))
  56  |     await login(page, path)
  57  |     await expect(page.getByRole('navigation', { name: 'Navegação da conta' })).toBeVisible()
  58  |     await logout(page)
  59  |   }
  60  | })
  61  | 
  62  | test('perfil editado persiste e sincroniza sessão sem apagar carrinho e favoritos', async ({ page }) => {
  63  |   await login(page)
  64  |   await api(page, '/cart/items', 'PUT', { nftId: 'emerald-ape-042', editionId: 'standard', quantity: 1, operation: 'add' })
  65  |   await api(page, '/users/user-ana/favorites/emerald-ape-042', 'PUT')
  66  |   await page.getByLabel('Nome de exibição', { exact: false }).fill('Ana Nova')
  67  |   await page.getByLabel('Nome de usuário', { exact: false }).fill('ana.nova')
  68  |   await page.getByLabel('E-mail', { exact: false }).fill('ANA.NOVA@kurio.test')
  69  |   await page.getByLabel('Nome ENS (opcional)').fill('ana.nova.eth')
  70  |   await page.getByLabel('Apelido da carteira (público)').fill('Coleção Ana')
  71  |   expect((await saveProfile(page)).status()).toBe(200)
  72  |   await expect(page.getByRole('status').filter({ hasText: 'Perfil salvo com sucesso.' })).toBeVisible()
  73  |   expect((await api<Session>(page, '/session')).data.user).toMatchObject({ name: 'Ana Nova', email: 'ana.nova@kurio.test' })
  74  |   await page.reload()
  75  |   await expect(page.getByLabel('Nome de exibição', { exact: false })).toHaveValue('Ana Nova')
  76  |   await expect(page.getByLabel('Nome de usuário', { exact: false })).toHaveValue('ana.nova')
  77  |   await expect(page.getByLabel('E-mail', { exact: false })).toHaveValue('ana.nova@kurio.test')
  78  |   expect((await api<{ items: unknown[] }>(page, '/cart')).data.items).toHaveLength(1)
  79  |   expect((await api<{ nftIds: string[] }>(page, '/users/user-ana/favorites')).data.nftIds).toEqual(['emerald-ape-042'])
  80  | })
  81  | 
  82  | test('validação cliente/MSW e conflitos de email, username e versão', async ({ page }) => {
  83  |   await login(page)
  84  |   await page.getByLabel('Nome de exibição', { exact: false }).fill('A')
  85  |   await page.getByRole('button', { name: 'Salvar', exact: true }).click()
  86  |   await expect(page.getByLabel('Nome de exibição', { exact: false })).toHaveAttribute('aria-invalid', 'true')
  87  |   await expect(page.getByLabel('Nome de exibição', { exact: false })).toBeFocused()
  88  |   const original = (await api<Profile>(page, profilePath)).data
  89  |   expect((await api(page, profilePath, 'PUT', { ...original, email: 'invalid' })).status).toBe(422)
  90  |   await page.getByLabel('Nome de exibição', { exact: false }).fill('Ana')
  91  |   await page.getByLabel('E-mail', { exact: false }).fill('bruno@kurio.test')
  92  |   expect((await saveProfile(page)).status()).toBe(409)
  93  |   await expect(page.getByLabel('E-mail', { exact: false })).toHaveAttribute('aria-invalid', 'true')
  94  |   await page.getByLabel('E-mail', { exact: false }).fill('ana@kurio.test')
  95  |   await page.getByLabel('Nome de usuário', { exact: false }).fill('BRUNO')
  96  |   expect((await saveProfile(page)).status()).toBe(409)
  97  |   expect((await api(page, profilePath, 'PUT', { ...original, displayName: 'Ana Externa' })).status).toBe(200)
  98  |   await page.getByLabel('Nome de usuário', { exact: false }).fill('ana')
  99  |   expect((await saveProfile(page)).status()).toBe(409)
  100 |   await page.getByRole('button', { name: 'Recarregar dados' }).click()
  101 |   await expect(page.getByLabel('Nome de exibição', { exact: false })).toHaveValue('Ana Externa')
  102 | })
  103 | 
  104 | test('senha atual, confirmação e troca atômica sem persistir texto puro', async ({ page }) => {
  105 |   await login(page)
  106 |   await page.getByLabel('Nome de exibição', { exact: false }).fill('Ana Segura')
  107 |   await page.getByLabel('Senha atual', { exact: true }).fill('Incorreta!123')
  108 |   await page.getByLabel('Nova senha', { exact: true }).fill('NovaSenha!456')
  109 |   await page.getByLabel('Confirmar nova senha').fill('Diferente!456')
  110 |   await page.getByRole('button', { name: 'Salvar', exact: true }).click()
  111 |   await expect(page.getByLabel('Confirmar nova senha')).toHaveAttribute('aria-invalid', 'true')
  112 |   await page.getByLabel('Confirmar nova senha').fill('NovaSenha!456')
  113 |   expect((await saveProfile(page)).status()).toBe(422)
  114 |   expect((await api<Profile>(page, profilePath)).data.displayName).toBe('Ana')
  115 |   await page.getByLabel('Senha atual', { exact: true }).fill('KurioDemo!123')
  116 |   expect((await saveProfile(page)).status()).toBe(200)
  117 |   await expect(page.getByLabel('Senha atual', { exact: true })).toHaveValue('')
  118 |   expect(await page.evaluate(() => JSON.stringify(localStorage))).not.toContain('NovaSenha!456')
  119 |   expect((await api(page, '/session', 'POST', { email: 'ana@kurio.test', password: 'KurioDemo!123' })).status).toBe(401)
  120 |   await logout(page)
  121 |   await login(page, '/perfil', 'ana', 'NovaSenha!456')
  122 |   await expect(page.getByLabel('Nome de exibição', { exact: false })).toHaveValue('Ana Segura')
  123 | })
  124 | 
  125 | test('avatar valida tipo, tamanho e conteúdo; alteração e remoção persistem', async ({ page }) => {
  126 |   await login(page)
  127 |   const input = page.getByLabel('Arquivo do avatar')
  128 |   await input.setInputFiles({ name: 'avatar.svg', mimeType: 'image/svg+xml', buffer: Buffer.from('<svg/>') })
  129 |   await expect(page.getByRole('alert')).toContainText('PNG, JPEG ou WebP')
  130 |   await input.setInputFiles({ name: 'grande.png', mimeType: 'image/png', buffer: Buffer.alloc(512 * 1024 + 1) })
  131 |   await expect(page.getByRole('alert')).toContainText('512 KB')
  132 |   const original = (await api<Profile>(page, profilePath)).data
  133 |   expect((await api(page, profilePath, 'PUT', { ...original, avatar: 'data:image/png;base64,AAAA' })).status).toBe(422)
  134 |   const png = Buffer.from(await page.evaluate(() => { const canvas = document.createElement('canvas'); canvas.width = canvas.height = 2; const context = canvas.getContext('2d')!; context.fillStyle = '#d68d49'; context.fillRect(0, 0, 2, 2); return canvas.toDataURL('image/png').split(',')[1]! }), 'base64')
  135 |   await input.setInputFiles({ name: 'avatar.png', mimeType: 'image/png', buffer: png })
  136 |   await expect(page.getByRole('img', { name: 'Avatar do colecionador' })).toBeVisible()
  137 |   expect((await saveProfile(page)).status()).toBe(200)
  138 |   await page.reload()
  139 |   await expect(page.getByRole('img', { name: 'Avatar do colecionador' })).toBeVisible()
  140 |   await page.getByRole('button', { name: 'Remover', exact: true }).click()
  141 |   expect((await saveProfile(page)).status()).toBe(200)
  142 |   await page.reload()
  143 |   await expect(page.getByRole('img', { name: 'Avatar do colecionador' })).toHaveCount(0)
  144 | })
  145 | 
  146 | test('carteiras: cadastro, edição, duplicata, rede e promoção persistentes', async ({ page }) => {
```